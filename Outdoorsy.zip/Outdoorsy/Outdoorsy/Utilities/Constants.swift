//
//  Constants.swift
//  Outdoorsy
//
//  Created by Dileep V on 3/5/21.
//  Copyright © 2021 Dileep V. All rights reserved.
//

import Foundation

let searchTitle = "Keyword Search"
