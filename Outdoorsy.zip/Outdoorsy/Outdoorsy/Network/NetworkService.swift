//
//  NetworkService.swift
//  Outdoorsy
//
//  Created by Dileep V on 3/5/21.
//  Copyright © 2021 Dileep V. All rights reserved.
//

import Foundation

typealias successBlock = (_ result: [Vehicle]) -> Void
typealias failureBlock = (_ errMsg: String) -> Void


class WebService {
    // Returns list of vehicles as callback
    class func parseVehicleData(successHandler:@escaping successBlock, failureHandler:@escaping failureBlock) {
        self.execute(url: API.getVehiclesData()) { (result, errMsg) in
            if errMsg == nil {
                do {
                    let response = try JSONDecoder().decode(VehicleResponse.self, from: result as! Data)
                    successHandler(response.vehicle)
                } catch {
                    failureHandler(error.localizedDescription)
                }
            } else {
                failureHandler(errMsg! as String)
            }
        }
    }
    
    // Makes an API Call
    private
    class func execute(url: String, completionBlock:@escaping (Any?, String?) -> ()) {
        let params = ["filter[keywords]":"trailer","page[limit]":8,"page[offset]":8] as [String : Any]
        var queryItems = [URLQueryItem]()
        for (key,value) in params {
            queryItems.append(URLQueryItem(name: key, value: "\(value)"))
        }
    
        var urlComps = URLComponents(string: url)!
        urlComps.queryItems = queryItems
        let resultUrl = urlComps.url!
        let task = URLSession.shared.dataTask(with: resultUrl, completionHandler: { (data, response, error) in
            if let result = data {
                completionBlock(result, nil)
            } else {
                completionBlock(nil, error?.localizedDescription)
            }
        })
        
        task.resume()
    }
}
