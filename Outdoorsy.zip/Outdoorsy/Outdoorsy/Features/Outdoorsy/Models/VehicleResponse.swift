//
//  Vehicle.swift
//  Outdoorsy
//
//  Created by Dileep V on 3/6/21.
//  Copyright © 2021 Dileep V. All rights reserved.
//

import Foundation

struct VehicleResponse: Codable {
    let vehicle: [Vehicle]
    enum CodingKeys: String, CodingKey {
        case vehicle = "data"
    }
}

// MARK: - Vehicle
struct Vehicle: Codable {
    let attributes: Attributes
}


// MARK: - Attributes
struct Attributes: Codable, Equatable, Comparable {
    static func < (lhs: Attributes, rhs: Attributes) -> Bool {
        return false
    }
    
    static func == (lhs: Attributes, rhs: Attributes) -> Bool {
        return false
    }
    
    let vehicleYear: Int?
    let name: String?
    let primaryImageURL: String?
    let vehicleMake: String?
    let vehicleModel: String?

    enum CodingKeys: String, CodingKey {
        case vehicleYear = "vehicle_year"
        case name
        case primaryImageURL = "primary_image_url"
        case vehicleMake = "vehicle_make"
        case vehicleModel = "vehicle_model"
    }
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        do {
            self.vehicleYear = try container.decode(Int.self, forKey: .vehicleYear)
        } catch {
            self.vehicleYear = nil
        }
        
        do {
            self.name = try container.decode(String.self, forKey: .name)
        } catch {
            self.name = nil
        }
        
        do {
            self.vehicleMake = try container.decode(String.self, forKey: .vehicleMake)
        } catch {
            self.vehicleMake = nil
        }
        
        do {
            self.primaryImageURL = try container.decode(String.self, forKey: .primaryImageURL)
        } catch {
            self.primaryImageURL = nil
        }
        
        do {
            self.vehicleModel = try container.decode(String.self, forKey: .vehicleModel)
        } catch {
            self.vehicleModel = nil
        }
        
    }
    
}


