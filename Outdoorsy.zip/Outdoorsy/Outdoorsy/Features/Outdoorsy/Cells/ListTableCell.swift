//
//  ListTableCell.swift
//  Outdoorsy
//
//  Created byDileep V on 3/5/21.
//  Copyright © 2021 Dileep V. All rights reserved.
//

import UIKit

class ListTableCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var vehicleImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    // Configuring Cell with Data
    func configure(attributes: Attributes) {
        titleLabel.text = attributes.name
        guard let imageUrl = attributes.primaryImageURL else
        {return}
        
        if let imgurl = URL(string: imageUrl){
            self.vehicleImageView.sd_setImage(with: imgurl)
        }
    }
    
}
