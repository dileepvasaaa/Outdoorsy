//
//  VehicleListViewModel.swift
//  Outdoorsy
//
//  Created by Dileep V on 3/6/21.
//  Copyright © 2021 Dileep V. All rights reserved.
//

import Foundation
import UIKit

protocol VehicleListViewModelProtocol {
    var tableTitle: String { get }
    var isSearchOn: Bool { get set}
    func searchString(searchText: String, response: @escaping () -> Void)
    func numberOfRowsInSection(section: Int) -> Int
    func getItemAt(indexPath: IndexPath) -> Attributes?
    func getVehicles(response: @escaping (Bool) -> Void)
}

class VehicleListViewModel: VehicleListViewModelProtocol {
    
    private var searchResults: [Vehicle]?
    
    var isSearchOn = false
    
    private var vehicles: [Vehicle]?
    
    var tableTitle: String {
        return searchTitle
    }
    
    // Returns NumberOfRows For TableView
    func numberOfRowsInSection(section: Int) -> Int {
        if isSearchOn {
            return searchResults?.count ?? 0
        }
        return vehicles?.count ?? 0
    }
    
    // Returns Item For Each Row Of TableView
    func getItemAt(indexPath: IndexPath) -> Attributes? {
        if isSearchOn {
            return searchResults?[indexPath.row].attributes
        }
        return vehicles?[indexPath.row].attributes
    }
    
    // Getting Vehicles data from API
    func getVehicles(response: @escaping (Bool) -> Void) {
        WebService.parseVehicleData(successHandler: {[weak self] (resultedVehicle) in
            self?.vehicles = resultedVehicle
            response(true)
        }) { (errMsg) in
            response(false)
        }
    }
    
    // This function is used to search attributes
    func searchString(searchText: String, response: @escaping () -> Void) {
        if searchText.isEmpty {
            isSearchOn = false
        } else {
            isSearchOn = true
            if let data = vehicles {
                searchResults = data.filter { (obj) -> Bool in
                    if let name = obj.attributes.name {
                        return name.localizedCaseInsensitiveContains(searchText)
                    }
                    else { return false }
                }
            }
        }
        response()
    }
}
