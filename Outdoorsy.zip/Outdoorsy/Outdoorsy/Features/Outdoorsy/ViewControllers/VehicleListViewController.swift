//
//  VehicleListViewController.swift
//  Outdoorsy
//
//  Created by Dileep V on 3/6/21.
//  Copyright © 2021 Dileep V. All rights reserved.
//

import UIKit

class VehicleListViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var viewModel: VehicleListViewModelProtocol = VehicleListViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        getVehicles()
    }
    
    // Initial setup of view
    func setup() {
        title = viewModel.tableTitle
        tableView.estimatedRowHeight = 100
        tableView.tableFooterView = UIView()
    }
    
    //Getting Restaurants data from ViewModel
    func getVehicles() {
        viewModel.getVehicles {[weak self] (success) in
            if success {
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            } else {
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Error", message: "Error loading data", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    
                    self?.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
}

extension VehicleListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRowsInSection(section: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ListTableCell", for: indexPath) as? ListTableCell else {
            return UITableViewCell()
        }
        if let attributes = viewModel.getItemAt(indexPath: indexPath)  {
            cell.configure(attributes: attributes)
        }
        return cell
    }
}

extension VehicleListViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.searchString(searchText: searchText) { [weak self] () in
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        
    }
}
